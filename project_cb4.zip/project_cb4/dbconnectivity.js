const mysql = require("mysql2");


const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Bhushan@2',
    database: 'cravebites_db'
});

connection.connect((err) => {
    if (err) throw err;
    console.log("Connected to the database!");
});

module.exports = connection;

