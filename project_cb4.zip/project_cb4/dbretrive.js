const connection = require('./dbconnectivity.js');

connection.query("SELECT * FROM user_login", (err, result) => {
    if (err) throw err;
    console.log("Users :", result);
});
