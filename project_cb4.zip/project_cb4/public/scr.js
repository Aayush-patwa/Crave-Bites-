let slideIndex = 1;
showSlides(slideIndex);

// Manual controls
function plusSlides(n) {
    showSlides(slideIndex += n);
}

// Core function to display slides
function showSlides(n) {
    const slides = document.getElementsByClassName("slide");
    if (n > slides.length) { slideIndex = 1 }
    if (n < 1) { slideIndex = slides.length }
    for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    slides[slideIndex - 1].style.display = "block";
}

// Automatic slideshow every 5 seconds
setInterval(() => {
    plusSlides(1);
}, 2000); // Change interval here if needed (5000 ms = 5s)
