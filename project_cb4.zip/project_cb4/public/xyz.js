// Keep existing cart functionality
let cart = JSON.parse(localStorage.getItem("cart")) || [];

// Modified addToCart function to check login status first
function addToCart(productName, price) {
    // Check if user is logged in before adding to cart
    fetch('/api/user')
        .then(response => response.json())
        .then(data => {
            if (!data.isLoggedIn) {
                // User is not logged in - ask them to login
                if (confirm('You need to be logged in to add items to cart. Go to login page?')) {
                    // Save the current page URL to redirect back after login
                    localStorage.setItem('loginRedirect', window.location.href);
                    window.location.href = '/login';
                }
                return;
            }

            // User is logged in, proceed with adding to cart
            const existing = cart.find(item => item.name === productName);
            if (existing) {
                existing.quantity++;
            } else {
                cart.push({ name: productName, price: price, quantity: 1 });
            }
            saveAndUpdateCart();

            // Show a small notification
            showNotification(`${productName} added to cart!`);
        })
        .catch(error => {
            console.error('Error checking login status:', error);
            alert('Error adding to cart. Please try again.');
        });
}

// Add a simple notification function
function showNotification(message) {
    // Create notification element if it doesn't exist
    let notification = document.getElementById('cart-notification');
    if (!notification) {
        notification = document.createElement('div');
        notification.id = 'cart-notification';
        notification.style.position = 'fixed';
        notification.style.bottom = '20px';
        notification.style.right = '20px';
        notification.style.backgroundColor = '#4CAF50';
        notification.style.color = 'white';
        notification.style.padding = '10px';
        notification.style.borderRadius = '5px';
        notification.style.zIndex = '1000';
        notification.style.opacity = '0';
        notification.style.transition = 'opacity 0.3s';
        document.body.appendChild(notification);
    }

    // Show notification with message
    notification.textContent = message;
    notification.style.opacity = '1';

    // Hide after 3 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
    }, 3000);
}

// Function to handle logout
function logout() {
    // Call the server logout endpoint
    fetch('/logout')
        .then(response => {
            if (response.ok) {
                // Clear cart from localStorage
                localStorage.removeItem('cart');
                cart = [];

                // Show notification
                showNotification('You have been logged out');

                // Update the auth buttons
                updateAuthButtons(false);

                // Update cart display
                updateCart();

                // Redirect to home page after a short delay
                setTimeout(() => {
                    window.location.href = '/';
                }, 1500);
            }
        })
        .catch(error => {
            console.error('Error during logout:', error);
            alert('Error during logout. Please try again.');
        });
}
function logout() {
    // Clear any client-side storage
    localStorage.removeItem('userToken'); // If you store auth token
    localStorage.removeItem('userData');  // If you store user data

    // Redirect to index page
    window.location.href = '/index.html';
}

// Function to update authentication buttons based on login status
function updateAuthButtons(isLoggedIn, username) {
    const authButtonsContainer = document.getElementById('auth-buttons');
    if (!authButtonsContainer) return;

    authButtonsContainer.innerHTML = '';

    if (isLoggedIn) {
        // Create user dropdown container
        const userDropdown = document.createElement('div');
        userDropdown.className = 'user-dropdown';
        userDropdown.style.position = 'relative';
        userDropdown.style.display = 'inline-block';

        // Create the button
        const userButton = document.createElement('button');
        userButton.className = 'user-btn';
        userButton.textContent = username || 'My Account';
        userButton.style.backgroundColor = '#4CAF50';
        userButton.style.color = 'white';
        userButton.style.border = 'none';
        userButton.style.padding = '5px 10px';
        userButton.style.borderRadius = '4px';
        userButton.style.cursor = 'pointer';

        // Create dropdown content
        const dropdownContent = document.createElement('div');
        dropdownContent.className = 'dropdown-content';
        dropdownContent.style.display = 'none';
        dropdownContent.style.position = 'absolute';
        dropdownContent.style.backgroundColor = '#f9f9f9';
        dropdownContent.style.minWidth = '160px';
        dropdownContent.style.boxShadow = '0px 8px 16px 0px rgba(0,0,0,0.2)';
        dropdownContent.style.zIndex = '1';

        // Create "My Orders" link
        const ordersLink = document.createElement('a');
        ordersLink.href = '/dashboard.html';
        ordersLink.textContent = 'My Orders';
        ordersLink.style.color = 'black';
        ordersLink.style.padding = '12px 16px';
        ordersLink.style.textDecoration = 'none';
        ordersLink.style.display = 'block';
        ordersLink.style.textAlign = 'left';

        // Hover effect for dropdown item
        ordersLink.onmouseover = function () {
            this.style.backgroundColor = '#f1f1f1';
        };
        ordersLink.onmouseout = function () {
            this.style.backgroundColor = 'transparent';
        };

        // Add link to dropdown
        dropdownContent.appendChild(ordersLink);

        // Toggle dropdown on button click
        userButton.onclick = function () {
            if (dropdownContent.style.display === 'block') {
                dropdownContent.style.display = 'none';
            } else {
                dropdownContent.style.display = 'block';
            }
        };

        // Close dropdown when clicking outside
        window.onclick = function (event) {
            if (!event.target.matches('.user-btn')) {
                dropdownContent.style.display = 'none';
            }
        };

        // Assemble dropdown
        userDropdown.appendChild(userButton);
        userDropdown.appendChild(dropdownContent);
        authButtonsContainer.appendChild(userDropdown);

        // Create logout button
        const logoutBtn = document.createElement('button');
        logoutBtn.textContent = 'Logout';
        logoutBtn.onclick = logout;
        logoutBtn.style.marginLeft = '10px';
        authButtonsContainer.appendChild(logoutBtn);
    } else {
        // Create login button
        const loginBtn = document.createElement('button');
        loginBtn.className = 'login-btn';
        loginBtn.textContent = 'Login';
        loginBtn.onclick = () => {
            localStorage.setItem('loginRedirect', window.location.href);
            window.location.href = '/login';
        };
        authButtonsContainer.appendChild(loginBtn);
    }
}

function removeFromCart(productName) {
    cart = cart.filter(item => item.name !== productName);
    saveAndUpdateCart();
}

function changeQuantity(productName, delta) {
    const item = cart.find(item => item.name === productName);
    if (!item) return;

    item.quantity += delta;
    if (item.quantity <= 0) {
        removeFromCart(productName);
    } else {
        saveAndUpdateCart();
    }
}

function saveAndUpdateCart() {
    localStorage.setItem("cart", JSON.stringify(cart));
    updateCart();
}

function updateCart() {
    const cartList = document.getElementById("cart-items");
    const totalElement = document.getElementById("total");
    const countBadge = document.getElementById("cart-count");

    if (!cartList || !totalElement || !countBadge) return;

    cartList.innerHTML = "";

    let total = 0;
    let itemCount = 0;

    cart.forEach(item => {
        const listItem = document.createElement("li");

        listItem.innerHTML = `
                ${item.name} - ₹${item.price.toFixed(2)} 
                <div class="cart-controls">
                    <button onclick="changeQuantity('${item.name}', -1)">➖</button>
                    <span>${item.quantity}</span>
                    <button onclick="changeQuantity('${item.name}', 1)">➕</button>
                    <button class="remove-btn" onclick="removeFromCart('${item.name}')">🗑️</button>
                </div>
            `;

        cartList.appendChild(listItem);
        total += item.price * item.quantity;
        itemCount += item.quantity;
    });

    totalElement.textContent = total.toFixed(2);
    countBadge.textContent = itemCount;
}

function toggleCart() {
    // Check if user is logged in before showing cart
    fetch('/api/user')
        .then(response => response.json())
        .then(data => {
            if (!data.isLoggedIn) {
                if (confirm('You need to be logged in to view your cart. Go to login page?')) {
                    localStorage.setItem('loginRedirect', window.location.href);
                    window.location.href = '/login';
                }
                return;
            }

            // User is logged in, show cart
            const cartSidebar = document.getElementById('cart-sidebar');
            const isVisible = cartSidebar.classList.contains('visible');

            if (isVisible) {
                cartSidebar.classList.remove('visible');
                cartSidebar.classList.add('hidden');
            } else {
                cartSidebar.classList.remove('hidden');
                cartSidebar.classList.add('visible');
                updateCart();
            }
        })
        .catch(error => {
            console.error('Error checking login status:', error);
        });
}

function checkoutCart() {
    // Check if user is logged in first
    fetch('/api/user')
        .then(response => response.json())
        .then(data => {
            if (!data.isLoggedIn) {
                // Redirect to login
                alert('Please log in to checkout');
                localStorage.setItem('loginRedirect', window.location.href);
                window.location.href = '/login';
                return;
            }

            // Get cart items
            const cart = JSON.parse(localStorage.getItem('cart')) || [];

            if (cart.length === 0) {
                alert('Your cart is empty');
                return;
            }

            // Calculate total
            const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

            // First, generate a new order ID
            fetch('/api/generate-order-id')
                .then(response => response.json())
                .then(orderData => {
                    if (!orderData.success) {
                        throw new Error('Failed to generate order ID');
                    }

                    // Now create checkout session with the order ID
                    return fetch('/api/create-checkout', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            orderId: orderData.orderId,
                            items: cart,
                            total: total
                        })
                    });
                })
                .then(response => response.json())
                .then(checkoutData => {
                    if (!checkoutData.success) {
                        throw new Error(checkoutData.message || 'Checkout failed');
                    }

                    // Redirect to payment page
                    window.location.href = checkoutData.redirectUrl;
                })
                .catch(error => {
                    console.error('Error during checkout:', error);
                    alert('Checkout failed: ' + error.message);
                });
        })
        .catch(error => {
            console.error('Error checking login status:', error);
            alert('Error during checkout. Please try again.');
        });
}

// Check login status and update UI accordingly
function checkLoginStatus() {
    fetch('/api/user')
        .then(response => response.json())
        .then(data => {
            // Update auth buttons based on login status
            updateAuthButtons(data.isLoggedIn, data.username);

            // If not logged in, clear the cart
            if (!data.isLoggedIn) {
                cart = [];
                localStorage.removeItem('cart');
                updateCart();
            }
        })
        .catch(error => {
            console.error('Error checking login status:', error);
        });
}

// Initialize cart count and check login status when page loads
document.addEventListener('DOMContentLoaded', function () {
    // Check login status first
    checkLoginStatus();

    // Initialize cart display
    updateCart();

    // Set up event listeners
    const cartToggleBtn = document.getElementById('cart-toggle-btn');
    if (cartToggleBtn) {
        cartToggleBtn.addEventListener('click', toggleCart);
    }

    // Check if we came back from a login redirect
    if (localStorage.getItem('loginRedirect')) {
        // Check if we're logged in now
        fetch('/api/user')
            .then(response => response.json())
            .then(data => {
                if (data.isLoggedIn) {
                    // We're logged in and came back from login page
                    // Clear the redirect URL
                    localStorage.removeItem('loginRedirect');

                    // Show notification
                    showNotification('Login successful! Welcome back.');
                }
            })
            .catch(error => {
                console.error('Error checking login status:', error);
            });
    }
});

// Authentication middleware
function isAuthenticated(req, res, next) {
    if (req.session && req.session.userId) {
        return next();
    }

    return res.status(401).json({ error: 'Not authenticated' });
}

// User authentication routes
app.post('/api/login', (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ error: 'Username and password are required' });
    }

    // Query to find user by username
    const query = 'SELECT id, User_Name FROM user_login WHERE User_Name = ? AND Password = ?';

    connection.query(query, [username, password], (err, results) => {
        if (err) {
            console.error('Error during login:', err);
            return res.status(500).json({ error: 'Database error' });
        }

        if (results.length === 0) {
            return res.status(401).json({ error: 'Invalid username or password' });
        }

        // User found, set session
        const user = results[0];
        req.session.userId = user.id;
        req.session.username = user.User_Name;

        res.json({
            success: true,
            user: {
                id: user.id,
                username: user.User_Name
            }
        });
    });
});

app.post('/api/logout', (req, res) => {
    if (req.session) {
        req.session.destroy(err => {
            if (err) {
                return res.status(500).json({ error: 'Could not log out' });
            }

            res.clearCookie('connect.sid'); // Clear the session cookie
            return res.json({ success: true });
        });
    } else {
        return res.json({ success: true });
    }
});

// Check user authentication status
app.get('/api/user', (req, res) => {
    if (req.session && req.session.userId) {
        return res.json({
            isLoggedIn: true,
            userId: req.session.userId,
            username: req.session.username
        });
    }

    return res.json({ isLoggedIn: false });
});