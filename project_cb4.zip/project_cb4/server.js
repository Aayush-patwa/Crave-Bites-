const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const session = require('express-session');
const connection = require('./dbconnectivity.js');

const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// Session setup
app.use(session({
    secret: 'cravebites_secret_key',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 3600000 } // 1 hour
}));

// Middleware to check if user is logged in
const isAuthenticated = (req, res, next) => {
    if (req.session.isLoggedIn) {
        return next();
    }
    res.redirect('/login');
};

// Serve home page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'home.html'));
});

// Serve signup page
app.get('/signup', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'signup.html'));
});

// Serve login page
app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// Handle signup form submission
app.post('/signup', (req, res) => {
    const { username, email, password } = req.body;

    // Basic validation
    if (!username || !email || !password) {
        return res.status(400).send('All fields are required');
    }

    // Insert user into database
    const query = "INSERT INTO user_login (user_name, password, Email) VALUES (?, ?, ?)";
    connection.query(query, [username, password, email], (err, result) => {
        if (err) {
            console.error('Error inserting user:', err);
            return res.status(500).send('Error registering user');
        }

        console.log('User registered successfully:', result);
        res.redirect('/login');
    });
});

// Modified login route to handle redirects
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const redirectUrl = req.query.redirect || '/';

    // Basic validation
    if (!username || !password) {
        return res.status(400).send('Username and password are required');
    }

    // Check if user exists in database
    const query = "SELECT * FROM user_login WHERE user_name = ? AND password = ?";
    connection.query(query, [username, password], (err, results) => {
        if (err) {
            console.error('Error logging in:', err);
            return res.status(500).send('Error during login');
        }

        if (results.length > 0) {
            // User found, set session
            req.session.isLoggedIn = true;
            req.session.username = username;
            req.session.userId = results[0].id; // Assuming there's an ID field

            console.log('Login successful for user:', username);

            // Redirect to the originally requested page if available
            return res.redirect(redirectUrl);
        } else {
            // User not found or incorrect password
            return res.status(401).send('Invalid username or password');
        }
    });
});

// Update login page route to accept redirect parameter
app.get('/login', (req, res) => {
    // Pass the redirect parameter to the login page
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
    // The login page will need to extract the redirect URL from query params
});

// Logout route
app.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error('Error during logout:', err);
        }
        res.redirect('/');
    });
});

// User data route to check login status
app.get('/api/user', (req, res) => {
    if (req.session.isLoggedIn) {
        res.json({
            isLoggedIn: true,
            username: req.session.username
        });
    } else {
        res.json({
            isLoggedIn: false
        });
    }
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});

// Add these routes to your existing server.js file

// Handle payment confirmation
// Modified confirm payment route to use transaction ID instead of order ID
app.post('/api/confirm-payment', isAuthenticated, (req, res) => {
    const { items, total, paymentMethod, transactionId } = req.body;
    const userId = req.session.userId;

    // Validate input
    if (!items || !total || !transactionId) {
        return res.status(400).json({ success: false, message: 'Missing required fields' });
    }

    // Generate a new order ID for internal use
    const timestamp = Date.now();
    const randomDigits = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    const orderId = `ORD-${timestamp}-${randomDigits}`;

    // Save order to database with the transaction ID
    const query = "INSERT INTO orders (order_id, user_id, amount, payment_method, transaction_id, status, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())";
    connection.query(query, [orderId, userId || null, total, paymentMethod || 'UPI', transactionId, 'PROCESSING'], (err, result) => {
        if (err) {
            console.error('Error creating order:', err);
            return res.status(500).json({ success: false, message: 'Database error' });
        }

        // Save order items if available
        if (items && items.length > 0) {
            const orderItems = items.map(item => [orderId, item.name, item.price, item.quantity]);
            const itemsQuery = "INSERT INTO order_items (order_id, product_name, price, quantity) VALUES ?";

            connection.query(itemsQuery, [orderItems], (err, result) => {
                if (err) {
                    console.error('Error saving order items:', err);
                    // Don't return error here, as the main order is already saved
                }

                // Return success
                return res.json({
                    success: true,
                    message: 'Order confirmed',
                    orderId: orderId,
                    redirectUrl: '/dashboard.html'
                });
            });
        } else {
            // No items, just return success
            return res.json({
                success: true,
                message: 'Order confirmed',
                orderId: orderId,
                redirectUrl: '/dashboard.html'
            });
        }
    });
});

// Serve the UPI checkout page
app.get('/upi-checkout.html', isAuthenticated, (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'upi-checkout.html'));
});

// Serve the payment success page
app.get('/payment-success.html', isAuthenticated, (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'payment-success.html'));
});

// Handle contact form submission
app.post('/submit-contact', (req, res) => {
    const { name, email, message } = req.body;

    // Basic validation
    if (!name || !email || !message) {
        return res.status(400).send('All fields are required');
    }

    // Insert contact submission into database
    const query = "INSERT INTO contact_submissions (name, email, message) VALUES (?, ?, ?)";
    connection.query(query, [name, email, message], (err, result) => {
        if (err) {
            console.error('Error saving contact submission:', err);
            return res.status(500).send('Error submitting your message');
        }

        console.log('Contact submission saved successfully:', result);

        // Redirect back to home page with success parameter
        res.redirect('/?contact=success');
    });
});

// Add these routes to your existing server.js file

// Generate a new order ID
app.get('/api/generate-order-id', isAuthenticated, (req, res) => {
    // Generate a unique order ID (you could use UUID or other methods)
    const timestamp = Date.now();
    const randomDigits = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    const orderId = `ORD-${timestamp}-${randomDigits}`;

    // Store the order ID in the user's session as "pending"
    if (!req.session.pendingOrders) {
        req.session.pendingOrders = {};
    }

    // Save order details in session with pending status
    req.session.pendingOrders[orderId] = {
        status: 'PENDING',
        createdAt: new Date(),
        items: [], // Will be filled during checkout
        total: 0  // Will be set during checkout
    };

    // Return the order ID to the client
    res.json({ success: true, orderId });
});

// Create a checkout session
app.post('/api/create-checkout', isAuthenticated, (req, res) => {
    const { orderId, items, total } = req.body;

    // Validate the order ID exists in session
    if (!req.session.pendingOrders || !req.session.pendingOrders[orderId]) {
        return res.status(400).json({ success: false, message: 'Invalid order ID' });
    }

    // Validate items and total
    if (!items || !Array.isArray(items) || items.length === 0) {
        return res.status(400).json({ success: false, message: 'No items in cart' });
    }

    // Update the pending order with items and total
    req.session.pendingOrders[orderId].items = items;
    req.session.pendingOrders[orderId].total = total;

    // Return success
    res.json({
        success: true,
        message: 'Checkout session created',
        redirectUrl: `/upi-checkout.html?orderId=${orderId}&total=${total}`
    });
});

// Validate order before showing payment page
app.get('/api/validate-order/:orderId', isAuthenticated, (req, res) => {
    const orderId = req.params.orderId;

    // Check if order exists in session
    if (!req.session.pendingOrders || !req.session.pendingOrders[orderId]) {
        return res.status(404).json({ valid: false, message: 'Order not found' });
    }

    // Check if order is still valid (e.g., not expired)
    const orderCreatedAt = new Date(req.session.pendingOrders[orderId].createdAt);
    const currentTime = new Date();
    const timeDiffMinutes = (currentTime - orderCreatedAt) / (1000 * 60);

    if (timeDiffMinutes > 30) { // Order expires after 30 minutes
        delete req.session.pendingOrders[orderId]; // Clean up expired order
        return res.status(400).json({ valid: false, message: 'Order expired' });
    }

    // Return order details
    res.json({
        valid: true,
        orderId: orderId,
        total: req.session.pendingOrders[orderId].total,
        status: req.session.pendingOrders[orderId].status
    });
});

// Modified confirm payment route
app.post('/api/confirm-payment', isAuthenticated, (req, res) => {
    const { orderId, paymentMethod } = req.body;

    // Validate the order exists
    if (!req.session.pendingOrders || !req.session.pendingOrders[orderId]) {
        return res.status(404).json({ success: false, message: 'Order not found' });
    }

    const orderDetails = req.session.pendingOrders[orderId];
    const items = orderDetails.items;
    const total = orderDetails.total;

    // Save order to database
    const query = "INSERT INTO orders (order_id, user_id, amount, payment_method, status, created_at) VALUES (?, ?, ?, ?, ?, NOW())";
    connection.query(query, [orderId, req.session.userId || null, total, paymentMethod || 'UPI', 'PROCESSING'], (err, result) => {
        if (err) {
            console.error('Error creating order:', err);
            return res.status(500).json({ success: false, message: 'Database error' });
        }

        // Save order items if available
        if (items && items.length > 0) {
            const orderItems = items.map(item => [orderId, item.name, item.price, item.quantity]);
            const itemsQuery = "INSERT INTO order_items (order_id, product_name, price, quantity) VALUES ?";

            connection.query(itemsQuery, [orderItems], (err, result) => {
                if (err) {
                    console.error('Error saving order items:', err);
                    // Don't return error here, as the main order is already saved
                }

                // Mark order as completed in session
                req.session.pendingOrders[orderId].status = 'PROCESSING';

                // Return success
                return res.json({
                    success: true,
                    message: 'Order confirmed',
                    orderId: orderId,
                    redirectUrl: '/payment-success.html?orderId=' + orderId
                });
            });
        } else {
            // No items, just return success
            req.session.pendingOrders[orderId].status = 'PROCESSING';
            return res.json({
                success: true,
                message: 'Order confirmed',
                orderId: orderId,
                redirectUrl: '/payment-success.html?orderId=' + orderId
            });
        }
    });
});

// Path to serve the payment success page with order ID
app.get('/payment-success.html', isAuthenticated, (req, res) => {
    const orderId = req.query.orderId;

    // Check if order ID is valid
    if (orderId && req.session.pendingOrders && req.session.pendingOrders[orderId]) {
        // Send success page
        res.sendFile(path.join(__dirname, 'public', 'payment-success.html'));
    } else {
        // Redirect to home page if invalid order
        res.redirect('/?error=invalid_order');
    }
});

// Get user orders with enhanced error handling
app.get('/api/user-orders', isAuthenticated, (req, res) => {
    const userId = req.session.userId;

    console.log(`Fetching orders for user ID: ${userId}`); // Debug info

    // Query to get all orders for the current user
    const query = `
        SELECT o.order_id, o.amount, o.payment_method, o.status, o.created_at,
               oi.product_name, oi.price, oi.quantity
        FROM orders o
        LEFT JOIN order_items oi ON o.order_id = oi.order_id
        WHERE o.user_id = ?
        ORDER BY o.created_at DESC
    `;

    connection.query(query, [userId], (err, results) => {
        if (err) {
            console.error('Error fetching user orders:', err);
            return res.status(500).json({ error: 'Database error', message: err.message });
        }

        console.log(`Found ${results.length} order records for user ${userId}`); // Debug info

        // Process the results to group items by order
        const orderMap = {};

        results.forEach((row, index) => {
            try {
                const orderId = row.order_id;

                if (!orderMap[orderId]) {
                    // Create new order object
                    orderMap[orderId] = {
                        orderId: orderId,
                        total: row.amount,
                        status: row.status,
                        paymentMethod: row.payment_method,
                        createdAt: row.created_at,
                        items: []
                    };
                }

                // Add item to order if it exists
                if (row.product_name) {
                    orderMap[orderId].items.push({
                        name: row.product_name,
                        price: row.price,
                        quantity: row.quantity
                    });
                }
            } catch (error) {
                console.error(`Error processing row ${index}:`, error, row);
            }
        });

        // Convert map to array
        const orders = Object.values(orderMap);
        console.log(`Processed ${orders.length} unique orders`); // Debug info

        res.json(orders);
    });
});

// Add a simple health check endpoint to verify API is working
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', message: 'API is working' });
});

// Add diagnostics endpoint to check database connection
app.get('/api/diagnostics', isAuthenticated, (req, res) => {
    connection.query('SELECT 1 as test', [], (err, results) => {
        if (err) {
            return res.status(500).json({
                status: 'error',
                message: 'Database connection failed',
                error: err.message
            });
        }

        res.json({
            status: 'ok',
            message: 'Database connection successful',
            userId: req.session.userId,
            username: req.session.username
        });
    });
});

// Add this middleware to prevent caching of authenticated pages
const preventAuthenticatedPageCaching = (req, res, next) => {
    if (req.session.isLoggedIn) {
        res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
        res.setHeader('Pragma', 'no-cache');
        res.setHeader('Expires', '0');
        res.setHeader('Surrogate-Control', 'no-store');
    }
    next();
};

// Apply this middleware to all routes
app.use(preventAuthenticatedPageCaching);

// Modify the logout route to handle back button properly
app.get('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error('Error during logout:', err);
        }
        // Set cache control headers to prevent returning to authenticated pages
        res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
        res.setHeader('Pragma', 'no-cache');
        res.setHeader('Expires', '0');
        res.setHeader('Surrogate-Control', 'no-store');
        res.redirect('/');
    });
});

// Add this route to check authentication status via AJAX
app.get('/api/check-auth', (req, res) => {
    res.json({ isLoggedIn: !!req.session.isLoggedIn });
});