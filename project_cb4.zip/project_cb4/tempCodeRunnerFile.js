app.post('/api/confirm-payment', isAuthenticated, (req, res) => {
    const { orderId, paymentMethod } = req.body;

    // Validate the order exists
    if (!req.session.pendingOrders || !req.session.pendingOrders[orderId]) {
        return res.status(404).json({ success: false, message: 'Order not found' });
    }

    const orderDetails = req.session.pendingOrders[orderId];
    const items = orderDetails.items;
    const total = orderDetails.total;

    // Save order to database
    const query = "INSERT INTO orders (order_id, user_id, amount, payment_method, status, created_at) VALUES (?, ?, ?, ?, ?, NOW())";
    connection.query(query, [orderId, req.session.userId || null, total, paymentMethod || 'UPI', 'PROCESSING'], (err, result) => {
        if (err) {
            console.error('Error creating order:', err);
            return res.status(500).json({ success: false, message: 'Database error' });
        }

        // Save order items if available
        if (items && items.length > 0) {
            const orderItems = items.map(item => [orderId, item.name, item.price, item.quantity]);
            const itemsQuery = "INSERT INTO order_items (order_id, product_name, price, quantity) VALUES ?";

            connection.query(itemsQuery, [orderItems], (err, result) => {
                if (err) {
                    console.error('Error saving order items:', err);
                    // Don't return error here, as the main order is already saved
                }

                // Mark order as completed in session
                req.session.pendingOrders[orderId].status = 'PROCESSING';

                // Return success
                return res.json({
                    success: true,
                    message: 'Order confirmed',
                    orderId: orderId,
                    redirectUrl: '/payment-success.html?orderId=' + orderId
                });
            });
        } else {
            // No items, just return success
            req.session.pendingOrders[orderId].status = 'PROCESSING';
            return res.json({
                success: true,
                message: 'Order confirmed',
                orderId: orderId,
                redirectUrl: '/payment-success.html?orderId=' + orderId
            });
        }
    });
});